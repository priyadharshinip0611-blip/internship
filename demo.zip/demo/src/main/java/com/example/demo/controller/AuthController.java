package com.example.demo.controller;


import com.example.demo.entity.User;
import com.example.demo.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor

public class AuthController {

    private final AuthService authService;

    @PostMapping("/register")
    public String register(@RequestBody User user) {
        return authService.register(user);
    }

    @GetMapping("/user")
public User getCurrentUser(Authentication authentication) {
    return (User) authentication.getPrincipal();
}

  @PostMapping("/login")
public Map<String, Object> login(@RequestBody Map<String, String> request) {
    return authService.login(
            request.get("email"),
            request.get("password")
    );
}

}
